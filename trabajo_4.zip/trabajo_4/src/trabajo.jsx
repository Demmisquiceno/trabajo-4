import React from "react";
import { useState } from "react";
import './trabajo.css'

function Trabajo() {
    const [Titulo, setCambio] = useState('Curso de React JS');
    const [Software, setSoftware] = useState('Visual studio code');
    const [Texto, setTexto] = useState('un curso');
    const [Nueva_Imagen, setImagen] = useState('../public/img/car.jpg');

const ChangeCourse  = (e) => {
    e.preventDefault()
    const valueInput = e.target.previousSibling.value;
    setCambio(valueInput)

    e.target.previousSibling.value='';
}
const ChangeCourse_Software  = (e) => {
    e.preventDefault()
    const valueInput = e.target.previousSibling.value;
    setSoftware(valueInput)

    e.target.previousSibling.value='';
}
const ChangeCourse_Texto = (e) => {
    e.preventDefault()
    const valueInput = e.target.previousSibling.value;
    setTexto(valueInput)

    e.target.previousSibling.value='';
}

const ChangeCourse_Nueva_Imagen= (e) => {
    e.preventDefault()
    const valueInput = e.target.previousSibling.value;
    setImagen(valueInput)

    e.target.previousSibling.value='';
}


    return (
        <div>
            <div className="row">
                <div className="col-12 col-lg-6">
                    <div className="col d-flex flex-column justify-content-center text-while" style=
                        {{
                            background: `url(${Nueva_Imagen}) center/cover`
                        }}>
                        <h1>{Titulo}</h1>
                        <h3>{Software}</h3>
                        <p>{Texto}</p>
                    </div>
                </div>
                <div className="col-12 col-lg-6">
                    <form className="col d-flex flex-column justify-content-center text-while" action="">
                        <input type="text" className="from-control" name="nombre" placeholder="nombre del curso" />
                        <button onClick={ChangeCourse} className="btn btn-primary" >Actulizar</button>

                        <input type="text" className="from-control" name="nombre" placeholder="Software" />
                        <button onClick={ChangeCourse_Software} className="btn btn-primary" >Actulizar</button>  

                        <textarea name="Texto" className="form-control" placeholder="Texto" id="" cols="30" rows="10">
                        </textarea>
                            <button onClick={ChangeCourse_Texto } className="btn btn-primary">Actulizar</button>
                    </form>
                    <div className="mt-3" onClick={ChangeCourse_Nueva_Imagen} >
                        <img src="../public/Img/3d.jpg" style={{width:'90px', cursor:'pointer'}} alt="" />
                        <img src="../public/Img/game.PNG" style={{width:'90px', cursor:'pointer'}} alt="" />
                        <img src="../public/Img/film.jpg" style={{width:'90px', cursor:'pointer'}} alt="" />
                    </div>
                </div>
            </div>
        </div>
    )
}
export default Trabajo